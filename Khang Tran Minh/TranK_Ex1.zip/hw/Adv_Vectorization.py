import numpy as np
from numpy import genfromtxt
import matplotlib.pyplot as plt

# load data
data = genfromtxt('advertising.csv', delimiter=',')
parameters = data[1:, :3]
sales = data[1:, 3:]
data_size = parameters.shape[0]

# vector [x, b]
data = np.c_[parameters, np.ones((data_size, 1))]


# predict y based on x and predicted theta
def predict(x, theta):
    return x.dot(theta)


# compute gradient
def gradient(z, y, x):
    dtheta = 2 * x.T.dot(z - y)
    return dtheta


# update weights
def update_weight(theta, n, dtheta):
    theta_new = theta - n * dtheta
    return theta_new


# init weight
np.random.seed(3)
theta = np.random.rand(data.shape[1], 1)  # [b, w]

# how long/learning rate
epoch_max = 10
n = 0.00001

# main
losses = []  # for debug
for epoch in range(epoch_max):
    for i in range(data_size):
        # get a sample
        x = data[i:i + 1]
        y = sales[i:i + 1]

        # predict z
        z = predict(x, theta)

        # compute loss
        loss = (z - y) * (z - y)
        losses.append(loss[0][0])

        # compute gradient
        dtheta = gradient(z, y, x)

        # update weights
        theta = update_weight(theta, n, dtheta)


# graph
plt.plot(losses)  # test with losses[3:]
plt.xlabel('iteration')
plt.ylabel('losses')
plt.show()
