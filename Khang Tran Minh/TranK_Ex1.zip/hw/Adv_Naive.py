from numpy import genfromtxt
import matplotlib.pyplot as plt
import random

# load data
data = genfromtxt('advertising.csv', delimiter=',')
tv = list(data[1:, 0])
radio = list(data[1:, 1])
newspaper = list(data[1:, 2])
sales = list(data[1:, 3])
data_size = len(tv)


# forward
def predict(x, w, b):
    return x[0] * w[0] + x[1] * w[1] + x[2] * w[2] + b


# compute gradient
def gradient(z, y, x):
    dw1 = 2 * x[0] * (z - y)
    dw2 = 2 * x[1] * (z - y)
    dw3 = 2 * x[2] * (z - y)
    dw = [dw1, dw2, dw3]
    db = 2 * (z - y)
    return dw, db


# update weights
def update_weight(w, b, n, dw, db):
    w1_new = w[0] - n * dw[0]
    w2_new = w[1] - n * dw[1]
    w3_new = w[2] - n * dw[2]
    w_new = [w1_new, w2_new, w3_new]
    b_new = b - n * db
    return w_new, b_new


# init weights
random.seed(3)
w = list([random.random() for i in range(3)])
b = random.random()

# how long/learning rate
epoch_max = 10
n = 0.00001

# main
losses = []  # for debug
for epoch in range(epoch_max):
    for i in range(data_size):
        # get a sample
        x1 = tv[i]
        x2 = radio[i]
        x3 = newspaper[i]
        x = [x1, x2, x3]
        y = sales[i]

        # predict z
        z = predict(x, w, b)

        # compute loss
        loss = (z - y) * (z - y)
        losses.append(loss)

        # compute gradient
        dw, db = gradient(z, y, x)

        # update weights
        w, b = update_weight(w, b, n, dw, db)

# graph
plt.plot(losses)  # test with losses[3:]
plt.xlabel('iteration')
plt.ylabel('losses')
plt.show()
