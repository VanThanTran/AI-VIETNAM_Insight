from tensorflow import keras
import matplotlib.pyplot as plt

# Data Preparation
(train_images, train_labels), (test_images, test_labels) = keras.datasets.cifar10.load_data()

# Data Normalization [0,1]
train_images = train_images / 255.0
test_images = test_images / 255.0

# Create model
model = keras.models.Sequential([
    keras.Input(shape=(32, 32, 3)),

    keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
    keras.layers.BatchNormalization(),
    keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
    keras.layers.BatchNormalization(),
    keras.layers.MaxPooling2D((2, 2)),
    keras.layers.Dropout(0.2),

    keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
    keras.layers.BatchNormalization(),
    keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same'),
    keras.layers.BatchNormalization(),
    keras.layers.MaxPooling2D((2, 2)),
    keras.layers.Dropout(0.3),

    keras.layers.Conv2D(512, (3, 3), activation='relu', padding='same'),
    keras.layers.BatchNormalization(),
    keras.layers.Conv2D(1024, (3, 3), activation='relu', padding='same'),
    keras.layers.BatchNormalization(),
    keras.layers.MaxPooling2D((2, 2)),
    keras.layers.Dropout(0.4),

    keras.layers.Flatten(),

    keras.layers.Dense(512, activation='relu'),
    keras.layers.BatchNormalization(),
    keras.layers.Dropout(0.5),

    keras.layers.Dense(256, activation='relu'),
    keras.layers.BatchNormalization(),
    keras.layers.Dropout(0.6),

    keras.layers.Dense(10, activation='softmax')
])

# Declare optimization method and loss function
opt = keras.optimizers.Adam(learning_rate=10e-3)
model.compile(optimizer=opt,
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Training
history_data = model.fit(train_images, train_labels,
                         validation_data=(test_images, test_labels),
                         batch_size=512, epochs=25, verbose=2)

# Graph
plt.plot(history_data.history['accuracy'], label="train_accuracy")
plt.plot(history_data.history['val_accuracy'], label="val_accuracy")
plt.xlabel('iteration')
plt.ylabel('Accuracy')
plt.legend()
plt.show()
