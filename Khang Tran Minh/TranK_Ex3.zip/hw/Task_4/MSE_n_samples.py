import numpy as np
import matplotlib.pyplot as plt

# load data
iris = np.genfromtxt('iris_Petal_Logistic.csv', dtype=None, delimiter=',', skip_header=1)
X = iris[:, :2]
y = iris[:, 2]

# vector [b, x]
intercept = np.ones((X.shape[0], 1))
X = np.concatenate((intercept, X), axis=1)

# shuffle
inds = np.arange(X.shape[0])
np.random.shuffle(inds)
X = X[inds]
y = y[inds]


def sigmoid_function(z):
    return 1 / (1 + np.exp(-z))


def loss_function(h, y):
    return np.multiply((h - y), (h - y)).mean()


def predict(X, theta):
    y_hat = sigmoid_function(np.dot(X, theta))
    return y_hat


def compute_gradient(X, y_hat, y):
    return 2 * np.dot(X.T, (y_hat - y) * y_hat * (1 - y_hat)) / y.size


# learning rate/ how-long
lr = 0.1
num_iter = 200

# initial theta
theta = np.array([0.1, 0.5, -0.1])

# for debug
losses = []
accs = []

for i in range(num_iter):
    # predict z
    y_hat = predict(X, theta)

    # compute loss
    loss = loss_function(y_hat, y)

    # compute mean of gradient
    gradient = compute_gradient(X, y_hat, y)

    theta -= lr * gradient

    # for debug
    if i % 1 == 0:
        # loss
        losses.append(loss)

        # accuracy for training
        preds = predict(X, theta).round()
        acc = (preds == y).mean()
        accs.append(acc)

# show figures
plt.plot(losses)
plt.xlabel('iteration')
plt.ylabel('losses')
plt.show()

# plt.plot(accs)
# plt.xlabel('iteration')
# plt.ylabel('accuracy')
# plt.show()
