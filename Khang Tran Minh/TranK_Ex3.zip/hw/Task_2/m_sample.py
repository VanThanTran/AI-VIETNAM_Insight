import numpy as np
import matplotlib.pyplot as plt

# load data
iris = np.genfromtxt('iris_Petal_Logistic.csv', dtype=None, delimiter=',', skip_header=1)
X = iris[:, :2]
Y = iris[:, 2]
data_size = X.shape[0]

# vector [b, x]
intercept = np.ones((X.shape[0], 1))
X = np.concatenate((intercept, X), axis=1)

# shuffle
inds = np.arange(X.shape[0])
np.random.shuffle(inds)
X = X[inds]
Y = Y[inds]


def sigmoid_function(z):
    return 1 / (1 + np.exp(-z))


def predict(x, theta):
    y_hat = sigmoid_function(np.dot(x, theta))
    return y_hat


def loss_function(h, y):
    return -y * np.log(h) - (1 - y) * np.log(1 - h)


def compute_gradient(x, y_hat, y):
    return np.dot(x.T, (y_hat - y)) / y.size


def update_theta(theta, lr, dtheta):
    theta_new = theta - lr * dtheta
    return theta_new


# learning rate/ how-long
lr = 0.01
epoch_max = 100

# initial theta/ mini-batch size
np.random.seed(3)
theta = np.random.rand(X.shape[1], 1)
m = 20

# for debug
losses = []
accs = []

for epoch in range(epoch_max):
    for i in range(0, data_size, m):
        # get a sample
        x = X[i:i + m]
        y = Y[i:i + m]

        # predict z
        y_hat = predict(x, theta)

        # compute loss
        loss = loss_function(y_hat, y)

        # compute mean of gradient
        gradient = compute_gradient(x, y_hat, y)

        # update theta
        theta = update_theta(theta, lr, gradient)

        # for debug
        if i % 1 == 0:
            # loss
            losses.append(np.mean(loss))

            # accuracy for training
            preds = y_hat.round()
            acc = (preds == y).mean()
            accs.append(acc)

# show figures
plt.plot(losses)
plt.xlabel('iteration')
plt.ylabel('losses')
plt.show()

# plt.plot(accs)
# plt.xlabel('iteration')
# plt.ylabel('accuracy')
# plt.show()
