import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import OneHotEncoder

# load data
iris = np.genfromtxt('iris_1D_2c.csv', dtype=None, delimiter=',', skip_header=1)
X = iris[:, 0:1]
y_label = iris[:, 1]
y_label = y_label.astype('uint8')

# covert label
onehot_encoder = OneHotEncoder(sparse=False)
y = y_label.reshape(len(y_label), 1)
y = onehot_encoder.fit_transform(y)

# vector [b, x]
intercept = np.ones((X.shape[0], 1))
X = np.concatenate((intercept, X), axis=1)
X = X.T

D = 1  # dimensionality
K = 2  # number of classes

# initialize parameters randomly
theta = np.random.randn(D + 1, K)

# gradient descent loop
num_examples = X.shape[1]
learning_rate = 0.1

losses = []
num_iter = 100
for epoch in range(num_iter):
    # evaluate class scores
    scores = np.dot(theta.T, X)

    # compute the class probabilities
    exp_scores = np.exp(scores)
    probs = exp_scores / np.sum(exp_scores, axis=0, keepdims=True)

    # compute the loss
    corect_logprobs = np.multiply(-np.log(probs), y.T)
    loss = np.sum(corect_logprobs)
    losses.append(loss)

    # compute the gradient on scores
    dscores = probs
    dscores -= y.T

    # backpropate the gradient to the parameters (W,b)
    dtheta = np.dot(X, dscores.T)

    # perform a parameter update
    theta += -learning_rate * dtheta

x_axis = range(len(losses))
plt.plot(x_axis, losses, color="r")
plt.show()

# evaluate training set accuracy
scores = np.dot(theta.T, X)
predicted_class = np.argmax(scores, axis=0)
print('Training accuracy: %.2f' % (np.mean(predicted_class == y_label)))
