import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import OneHotEncoder

# load data
iris = np.genfromtxt('iris_1D_2c.csv', dtype=None, delimiter=',', skip_header=1)
X = iris[:, 0:1]
y_label = iris[:, 1]
y_label = y_label.astype('uint8')

# covert label
onehot_encoder = OneHotEncoder(sparse=False)
y = y_label.reshape(len(y_label), 1)
y = onehot_encoder.fit_transform(y)

# vector [b, x]
intercept = np.ones((X.shape[0], 1))
X = np.concatenate((intercept, X), axis=1)

N = 3  # number of points per class
D = 1  # dimensionality
K = 2  # number of classes

# initialize parameters randomly
theta = np.array([[0.1, 0.05], [0.2, -0.1]])

# gradient descent loop
num_examples = X.shape[0]
learning_rate = 0.1

losses = []
num_iter = 100

num_sample_stochastic = 1
for epoch in range(num_iter):
    for i in range(num_examples):
        xi = X[i:i + 1]
        xi = xi.T
        yi = y[i:i + 1]

        # evaluate class scores
        scores = np.dot(theta.T, xi)

        # compute the class probabilities
        exp_scores = np.exp(scores)
        probs = exp_scores / np.sum(exp_scores, axis=0, keepdims=True)

        # compute the loss
        corect_logprobs = np.multiply(-np.log(probs), yi.T)
        loss = np.sum(corect_logprobs)
        losses.append(loss)

        # compute the gradient on scores
        dscores = probs
        dscores -= yi.T

        # backpropate the gradient to the parameters (W,b)
        dtheta = np.dot(xi, dscores.T)

        # perform a parameter update
        theta += -learning_rate * dtheta

x_axis = range(len(losses))
plt.plot(x_axis, losses, color="r")
plt.sjp

# evaluate training set accuracy
scores = np.dot(theta.T, X.T)
predicted_class = np.argmax(scores, axis=0)
print('Training accuracy: %.2f' % (np.mean(predicted_class == y)))
