import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Flatten, Dense
from tensorflow.keras.layers import Convolution2D, MaxPooling2D
import matplotlib.pyplot as plt

# Data Preparation
(train_images, train_labels), (test_images, test_labels) = keras.datasets.fashion_mnist.load_data()

# Data Normalization [0,1]
train_images = train_images / 255.0
test_images  = test_images / 255.0

# Reshape
train_images = tf.reshape(train_images, (60000, 28, 28, 1))
test_images  = tf.reshape(test_images, (10000, 28, 28, 1))

# Create Model
def VGG():
    model = Sequential()
    model.add(Convolution2D(64, 3, padding='same', activation='relu', input_shape=(28,28, 1)))
    model.add(Convolution2D(64, 3, padding='same', activation='relu'))
    model.add(MaxPooling2D((2,2), strides=(2,2)))

    model.add(Convolution2D(128, 3, padding='same', activation='relu'))
    model.add(Convolution2D(128, 3, padding='same', activation='relu'))
    model.add(MaxPooling2D((2,2), strides=(2,2)))

    model.add(Flatten())
    model.add(Dense(1024, activation='relu'))
    model.add(Dense(1024, activation='relu'))
    model.add(Dense(10, activation='softmax'))

    return model

# Declare optimization method and loss function
model = VGG()
model.compile(optimizer='adam',
              loss=tf.keras.losses.SparseCategoricalCrossentropy(),
              metrics=['accuracy'])

# Training
history_data = model.fit(train_images, train_labels,
                         validation_data=(test_images, test_labels),
                         batch_size=512, epochs=10, verbose=2)

# Graph
plt.plot(history_data.history['accuracy'], label="train_accuracy")
plt.plot(history_data.history['val_accuracy'], label="val_accuracy")
plt.xlabel('iteration')
plt.ylabel('Accuracy')
plt.legend()
plt.show()